// ==============================
// HOMES 
// ==============================

export const house = {
    foundations() {
        return "House foundations";
    },
    walls() {
        return "House walls";
    },
    roof() {
        return "House roof";
    }
};

export const building = {
    foundations() {
        return "Apartment building foundations";
    },
    walls() {
        return "Apartment building walls";
    },
    roof() {
        return "Apartment building roof";
    }
};
