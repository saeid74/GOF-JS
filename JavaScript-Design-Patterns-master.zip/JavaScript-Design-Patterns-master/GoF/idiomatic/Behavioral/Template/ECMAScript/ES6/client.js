import build from './API/template';
import { house, building } from './API/homes';

// ==============================
// CLIENT CODE 
// ==============================

console.log(build(house));
console.log(build(building));
