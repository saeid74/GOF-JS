// ==============================
// ORDER
// ==============================

export default {
    deliver() {
        return this.customer.pay(); 
    }
};
