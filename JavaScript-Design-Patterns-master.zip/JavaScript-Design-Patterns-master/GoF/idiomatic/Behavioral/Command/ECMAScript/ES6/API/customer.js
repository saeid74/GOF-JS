// ==============================
// CUSTOMER
// ==============================

export default { 
    pay() {
        return "Payment OK!\n";
    }
};
