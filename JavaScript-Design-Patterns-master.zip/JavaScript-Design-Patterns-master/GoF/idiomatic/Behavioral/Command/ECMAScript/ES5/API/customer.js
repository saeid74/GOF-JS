'use strict';

// ==============================
// CUSTOMER
// ==============================

module.exports = {
    pay: function () {
        return "Payment OK!\n";
    }
};
