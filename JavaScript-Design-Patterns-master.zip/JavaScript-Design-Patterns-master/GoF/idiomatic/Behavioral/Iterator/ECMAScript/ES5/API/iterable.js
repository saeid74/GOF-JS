'use strict';

// ==============================
// ITERABLE (LIBRARY) 
// ==============================

module.exports = {
    books: []
};
