// ==============================
// STRATEGIES
// ==============================

export const offense = {
    fight() {
        return "Fight with an offensive style";
    }
};

export const defense = {
    fight() {
        return "Fight with a defensive style";
    }
};
