// ==============================
// CARETAKER (BOOKMARKS MANAGER) 
// ==============================

export default {
    bookmarks: [],
    addBookmark(bookmark) {
        this.bookmarks.push(bookmark); 
    }
};
