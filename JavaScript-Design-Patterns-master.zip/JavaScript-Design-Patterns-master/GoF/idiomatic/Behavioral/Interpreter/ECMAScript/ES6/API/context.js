// ==============================
// CONTEXT (SONATA)
// ==============================

export default {
    name: "Moonlight Sonata",
    composer: "Beethoven"
};
