'use strict';

// ==============================
// CONTEXT (SONATA)
// ==============================

module.exports = {
    name: "Moonlight Sonata",
    composer: "Beethoven"
};
