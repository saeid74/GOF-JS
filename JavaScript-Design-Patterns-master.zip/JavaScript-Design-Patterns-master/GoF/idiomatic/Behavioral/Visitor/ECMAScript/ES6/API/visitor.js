// ==============================
// VISITOR (TOURIST)
// ==============================

export default {
    visit(monument) {
        return `Visiting ${monument.name}`;
    }
};
