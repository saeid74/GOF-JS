// ==============================
// ABSTRACT STRATEGY 
// ==============================

export default interface Strategy {
    fight(): string;
}
