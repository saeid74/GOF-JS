// ==============================
// CONCRETE CUSTOMER
// ==============================

export default class Customer {
    pay() {
        return "Payment OK!\n";
    }
}
