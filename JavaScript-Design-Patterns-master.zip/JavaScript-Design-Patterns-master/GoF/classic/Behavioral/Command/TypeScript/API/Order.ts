// ==============================
// ABSTRACT ORDER
// ==============================

export default interface Order {
    deliver(): string;
}
