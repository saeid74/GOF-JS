// ==============================
// ABSTRACT ITERABLE 
// ==============================

export default interface Collection {
    list(): Catalog;
}
