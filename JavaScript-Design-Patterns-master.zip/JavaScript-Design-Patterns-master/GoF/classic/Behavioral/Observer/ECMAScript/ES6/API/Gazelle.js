import Prey from './Prey';

// ==============================
// CONCRETE OBSERVABLE
// ==============================

export default class Gazelle extends Prey {
    constructor() {
        super(); 
    }
}
