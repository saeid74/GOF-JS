// ==============================
// ABSTRACT OBSERVER 
// ==============================

export default interface Predator {
    attack(): string;
}
