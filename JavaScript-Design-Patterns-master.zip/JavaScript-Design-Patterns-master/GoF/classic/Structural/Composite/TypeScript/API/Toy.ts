// ==============================
// ABSTRACT COMPONENT
// ==============================

export default interface Toy {
    description(): string;
}
