// ==============================
// ABSTRACT ANIMAL
// ==============================

export default interface Animal {
    eat(): string;
}
