// ==============================
// ABSTRACT PIZZA
// ==============================

export default interface Pizza {
    ingredients(): string;
}
