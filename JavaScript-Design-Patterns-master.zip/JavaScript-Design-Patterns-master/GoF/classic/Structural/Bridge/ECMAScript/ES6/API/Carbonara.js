import Sauce from './Sauce';

// ==============================
// CONCRETE SAUCE
// ==============================

export default class Carbonara extends Sauce {
    ingredients() {
        return "Carbonara (eggs, bacon, black pepper, grated cheese)";
    }
}
