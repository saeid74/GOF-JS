// ==============================
// ABSTRACTION
// ==============================

export default interface Sauce {
    ingredients(): string;
}
