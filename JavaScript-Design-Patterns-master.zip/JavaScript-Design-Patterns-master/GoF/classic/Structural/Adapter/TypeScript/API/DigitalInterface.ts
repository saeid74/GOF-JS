// ==============================
// ABSTRACT CONNECTION
// ==============================

export default interface DigitalInterface {
    handleDigitalSignal(): string;
}
