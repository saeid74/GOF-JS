// ==============================
// ABSTRACT CONNECTION
// ==============================

export default interface AnalogInterface {
    handleAnalogSignal(): string;
}
