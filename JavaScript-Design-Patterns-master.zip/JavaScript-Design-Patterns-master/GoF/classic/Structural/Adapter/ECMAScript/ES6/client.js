import HDMIToVGAAdapter from './API/HDMIToVGAAdapter';

// ==============================
// CLIENT CODE
// ==============================

let adapter = new HDMIToVGAAdapter();

console.log(adapter.handleDigitalSignal());
