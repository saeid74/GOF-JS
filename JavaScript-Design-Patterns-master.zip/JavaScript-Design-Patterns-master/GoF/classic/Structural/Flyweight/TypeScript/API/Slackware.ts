import LinuxDistro from './LinuxDistro';

// ==============================
// CONCRETE GNU/LINUX DISTROS
// ==============================

export default class Slackware extends LinuxDistro {
    constructor() {
        super("Slackware");
    }
}
