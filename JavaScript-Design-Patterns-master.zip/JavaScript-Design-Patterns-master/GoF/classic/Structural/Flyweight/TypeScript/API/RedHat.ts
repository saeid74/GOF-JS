import LinuxDistro from './LinuxDistro';

// ==============================
// CONCRETE GNU/LINUX DISTROS
// ==============================

export default class RedHat extends LinuxDistro {
    constructor() {
        super("RedHat");
    }
}
