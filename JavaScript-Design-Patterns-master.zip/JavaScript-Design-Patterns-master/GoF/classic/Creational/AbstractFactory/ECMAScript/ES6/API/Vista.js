import WindowsVersion from './WindowsVersion';

// ==============================
// CONCRETE WINDOWS VERSION
// ==============================

export default class Vista extends WindowsVersion {
    constructor() {
        super("Windows Vista");
    }
}
