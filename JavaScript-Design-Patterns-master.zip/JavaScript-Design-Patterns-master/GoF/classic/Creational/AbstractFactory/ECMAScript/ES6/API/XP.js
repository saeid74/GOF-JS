import WindowsVersion from './WindowsVersion';

// ==============================
// CONCRETE WINDOWS VERSION
// ==============================

export default class XP extends WindowsVersion {
    constructor() {
        super("Windows XP");
    }
}
