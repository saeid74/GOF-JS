import LinuxDistro from './LinuxDistro';

// ==============================
// CONCRETE GNU/LINUX DISTRO
// ==============================

export default class Debian extends LinuxDistro {
    constructor() {
        super("Debian");
    }   
}
