import LinuxDistro from './LinuxDistro';

// ==============================
// CONCRETE GNU/LINUX DISTRO
// ==============================

export default class RedHat extends LinuxDistro {
    constructor() {
        super("RedHat");
    }
}
