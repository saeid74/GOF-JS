// ==============================
// ABSTRACT PROTOTYPE
// ==============================

export default interface PaperSheet {
    photocopy(): PaperSheet; // clone method
}
